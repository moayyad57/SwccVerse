[goobie-verse](../README.md) / [Modules](../modules.md) / inventory/inventory-item/inventory-item.class

# Module: inventory/inventory-item/inventory-item.class

## Table of contents

### Classes

- [InventoryItem](../classes/inventory_inventory_item_inventory_item_class.InventoryItem.md)
