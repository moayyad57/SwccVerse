[goobie-verse](../README.md) / [Modules](../modules.md) / media/file-browser/file-browser.class

# Module: media/file-browser/file-browser.class

## Table of contents

### Classes

- [FileBrowserService](../classes/media_file_browser_file_browser_class.FileBrowserService.md)
