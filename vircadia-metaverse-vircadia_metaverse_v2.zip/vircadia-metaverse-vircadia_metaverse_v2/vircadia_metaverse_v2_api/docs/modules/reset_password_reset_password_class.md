[goobie-verse](../README.md) / [Modules](../modules.md) / reset-password/reset-password.class

# Module: reset-password/reset-password.class

## Table of contents

### Classes

- [ResetPassword](../classes/reset_password_reset_password_class.ResetPassword.md)
