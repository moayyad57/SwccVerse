[goobie-verse](../README.md) / [Modules](../modules.md) / media/avatar/avatar.class

# Module: media/avatar/avatar.class

## Table of contents

### Classes

- [Avatar](../classes/media_avatar_avatar_class.Avatar.md)
