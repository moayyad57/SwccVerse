[goobie-verse](../README.md) / [Modules](../modules.md) / init-master-data/init-master-data.class

# Module: init-master-data/init-master-data.class

## Table of contents

### Classes

- [InitMasterData](../classes/init_master_data_init_master_data_class.InitMasterData.md)
