[goobie-verse](../README.md) / [Modules](../modules.md) / inventory/inventory-transfer/inventory-transfer.class

# Module: inventory/inventory-transfer/inventory-transfer.class

## Table of contents

### Classes

- [InventoryTransfer](../classes/inventory_inventory_transfer_inventory_transfer_class.InventoryTransfer.md)
