[goobie-verse](../README.md) / [Modules](../modules.md) / email/email.class

# Module: email/email.class

## Table of contents

### Classes

- [Email](../classes/email_email_class.Email.md)
