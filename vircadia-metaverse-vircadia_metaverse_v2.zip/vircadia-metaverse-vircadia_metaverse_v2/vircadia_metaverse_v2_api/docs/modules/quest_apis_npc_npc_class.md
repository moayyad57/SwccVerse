[goobie-verse](../README.md) / [Modules](../modules.md) / quest\_apis/npc/npc.class

# Module: quest\_apis/npc/npc.class

## Table of contents

### Classes

- [Npc](../classes/quest_apis_npc_npc_class.Npc.md)
