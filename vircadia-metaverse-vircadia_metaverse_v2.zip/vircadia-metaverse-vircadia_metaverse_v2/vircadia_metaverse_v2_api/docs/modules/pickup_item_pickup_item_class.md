[goobie-verse](../README.md) / [Modules](../modules.md) / pickup-item/pickup-item.class

# Module: pickup-item/pickup-item.class

## Table of contents

### Classes

- [PickupItem](../classes/pickup_item_pickup_item_class.PickupItem.md)
