[goobie-verse](../README.md) / [Modules](../modules.md) / auth/auth.class

# Module: auth/auth.class

## Table of contents

### Classes

- [Auth](../classes/auth_auth_class.Auth.md)
