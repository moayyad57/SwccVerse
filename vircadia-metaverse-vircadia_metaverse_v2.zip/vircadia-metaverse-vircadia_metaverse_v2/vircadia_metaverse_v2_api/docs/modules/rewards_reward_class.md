[goobie-verse](../README.md) / [Modules](../modules.md) / rewards/reward.class

# Module: rewards/reward.class

## Table of contents

### Classes

- [RewardItem](../classes/rewards_reward_class.RewardItem.md)
