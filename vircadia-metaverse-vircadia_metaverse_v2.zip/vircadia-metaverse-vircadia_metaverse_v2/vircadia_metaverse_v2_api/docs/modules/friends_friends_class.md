[goobie-verse](../README.md) / [Modules](../modules.md) / friends/friends.class

# Module: friends/friends.class

## Table of contents

### Classes

- [Friends](../classes/friends_friends_class.Friends.md)
