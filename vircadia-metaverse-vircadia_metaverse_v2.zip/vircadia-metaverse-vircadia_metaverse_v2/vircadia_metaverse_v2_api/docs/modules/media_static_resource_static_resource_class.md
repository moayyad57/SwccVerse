[goobie-verse](../README.md) / [Modules](../modules.md) / media/static-resource/static-resource.class

# Module: media/static-resource/static-resource.class

## Table of contents

### Classes

- [StaticResource](../classes/media_static_resource_static_resource_class.StaticResource.md)
