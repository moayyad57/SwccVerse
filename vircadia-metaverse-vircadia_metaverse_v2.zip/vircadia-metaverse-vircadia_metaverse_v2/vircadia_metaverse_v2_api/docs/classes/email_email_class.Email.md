[goobie-verse](../README.md) / [Modules](../modules.md) / [email/email.class](../modules/email_email_class.md) / Email

# Class: Email

[email/email.class](../modules/email_email_class.md).Email

Email.

## Hierarchy

- `DatabaseService`

  ↳ **`Email`**

## Table of contents

### Constructors

- [constructor](email_email_class.Email.md#constructor)

## Constructors

### constructor

• **new Email**(`options`, `app`)

#### Parameters

| Name | Type |
| :------ | :------ |
| `options` | `Partial`<`DatabaseServiceOptions`\> |
| `app` | `Application` |

#### Overrides

DatabaseService.constructor

#### Defined in

[src/services/email/email.class.ts:27](https://github.com/digisomni-syndicate/vircadia-metaverse-v2/blob/4467f0e/src/services/email/email.class.ts#L27)
